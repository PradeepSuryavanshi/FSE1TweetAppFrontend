﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using TweetApp.Model;
using TweetApp.Model.DTO;
using TweetApp.Repository.IRepository;
using TweetApp.Service.ServiceInterface;
using TweetApp.ViewModel;

namespace TweetApp.Service
{
    public class TweetAppService : ITweetAppService
    {
        private readonly ITweetRepository _repository;
        private readonly IConfiguration _config;

        public TweetAppService(ITweetRepository repo, IConfiguration configuration)
        {
            this._repository = repo;
            this._config = configuration;
        }
        public async Task<string> Register(User user)
        {
            try
            {

                if (user != null)
                {
                    var Msg = string.Empty;
                    bool EmailExists = await _repository.CheckEmailExists(user.Email);
                    bool UserNameExists = await _repository.CheckUserNameExists(user.UserName);
                    if (!EmailExists && !UserNameExists)
                    {
                        user.Password = this.EncryptionPassword(user.Password);   // Password Encryption
                        var result = await _repository.Register(user);
                        if (result > 0)
                        {
                            Msg = "User Successfully Registered";
                        }
                        else
                        {
                            Msg = "Registration Failed";
                        }
                    }
                    else
                    {
                        if (EmailExists)
                        {
                            Msg = "Email Already Exists";
                        }
                        else if (UserNameExists)
                        {
                            Msg = "Username Already taken";
                        }
                    }
                    return Msg;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception e)
            {
                throw;
            }

        }

        public string EncryptionPassword(string password)
        {
            string EncryptionPassword = string.Empty;
            byte[] EncodedPass = new byte[password.Length];
            EncodedPass = Encoding.UTF8.GetBytes(password);
            EncryptionPassword = Convert.ToBase64String(EncodedPass);
            return EncryptionPassword;
        }

        public async Task<string> Login(string Password, string UserName)
        {
            try
            {
                string msg = string.Empty;

                if (Password != null && UserName != null)
                {
                    var EncryptionPassword = this.EncryptionPassword(Password);
                    UserDTO isLoginSuccess = await _repository.Login(EncryptionPassword, UserName);
                    if (isLoginSuccess != null)
                    {
                        //msg = "Login Successful";
                        string token = this.GenerateToken(UserName);
                        return token;
                    }
                    else
                    {
                        msg = "Invalid UserName or Password";
                        return null;
                    }
                }
                return null;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        private string GenerateToken(string UserName)
        {
            var claims = new List<Claim>
            {
                new Claim(JwtRegisteredClaimNames.Sub,UserName),
                new Claim(JwtRegisteredClaimNames.Jti,Guid.NewGuid().ToString()),
                new Claim(ClaimTypes.NameIdentifier,UserName),
                new Claim(ClaimTypes.Role,UserName),
            };

            var securityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(this._config["JwtKey"]));
            var UserCredentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var expires = DateTime.Now.AddDays(Convert.ToDouble(this._config["JwtExpireDays"]));
            var token = new JwtSecurityToken(
                this._config["JwtIssuer"],
                this._config["JwtIssuer"],
                claims,
                expires: expires,
                signingCredentials: UserCredentials);

            return new JwtSecurityTokenHandler().WriteToken(token);

        }

        public async Task<Tweet> PostTweet(Tweet tweet)
        {
            try
            {
                if (tweet != null)
                {
                    var result = await _repository.PostTweet(tweet);
                    return result;
                }
                return null;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        //Get All Tweets
        public async Task<List<Tweet>> GetAllTweets()
        {
            try
            {
                return await _repository.GetAllTweets();
            }
            catch (Exception e)
            {
                throw;
            }
        }

        //Get All Tweet By User
        public async Task<List<TweetViewModel>> GetAllTweetOfUser(string UserName)
        {
            try
            {
                var UserTweets = await _repository.GetAllTweetOfUser(UserName);
                return UserTweets;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        //Get All Users 
        public async Task<List<UsersViewModel>> GetAllUsers()
        {
            try
            {
                return await _repository.GetAllUsers();
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public async Task<UsersViewModel> GetUserByUserName(string UserName)
        {
            try
            {
                var user = await _repository.GetUserByUserName(UserName);
                if (user != null)
                {
                    return user;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public async Task<bool> UpdateTweet(int TweetId, string NewTweetContent)
        {
            try
            {
                bool result = await _repository.UpdateTweet(TweetId, NewTweetContent);
                return result;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public async Task<bool> DeleteTweet(int TweetId)
        {
            try
            {
                bool result = await _repository.DeleteTweet(TweetId);
                return result;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public async Task<int> Likes(string username, string tweet, int tweetId)
        {
            try
            {
                int result = await _repository.Likes(username, tweet, tweetId);
                return result;
            }
            catch (Exception e)
            {
                throw;
            }
        }
        public async Task<int> ReplyToTweet(string Reply, string Tweeterusername, string ReplyuserName, string tweet)
        {
            try
            {
                DateTime date = DateTime.Now;
                int result = await _repository.ReplyToTweet(Reply, Tweeterusername, ReplyuserName, tweet, date);
                return result;
            }
            catch (Exception e)
            {
                throw;
            }
        }
        public async Task<string> ResetPassword(string Email, string oldPass, string newPass)
        {
            try
            {
                if (oldPass != null & newPass != null)
                {
                    string encryptedOldPass = EncryptionPassword(oldPass);
                    string encryptedNewPass = EncryptionPassword(newPass);
                    string msg = string.Empty;
                    bool IsPassChanged = await _repository.ForgotPassword(Email, encryptedOldPass, encryptedNewPass);
                    if (IsPassChanged)
                    {
                        msg = "Password chnaged successfully";
                        return msg;
                    }
                    else
                    {
                        msg = "wrong Email and Old Password";
                        return msg;
                    }
                }
                return null;
            }
            catch (Exception e)
            {
                throw;
            }


        }
    }
}
