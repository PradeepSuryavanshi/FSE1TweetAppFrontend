﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetApp.Model;
using TweetApp.ViewModel;

namespace TweetApp.Service.ServiceInterface
{
    public interface ITweetAppService
    {
        public Task<string> Register(User user);
        public Task<string> Login(string password, string UserName);
        public Task<Tweet> PostTweet(Tweet tweet);
        public Task<List<Tweet>> GetAllTweets();
        public Task<List<TweetViewModel>> GetAllTweetOfUser(string UserName);
        public Task<List<UsersViewModel>> GetAllUsers();
        public Task<UsersViewModel> GetUserByUserName(string UserName);
        public Task<string> ResetPassword(string Email, string oldPass, string newPass);
        public Task<bool> UpdateTweet(int TweetId, string NewTweetContent);
        public Task<bool> DeleteTweet(int TweetID);
        public Task<int> Likes(string username, string tweet, int tweetId);
        public Task<int> ReplyToTweet(string Reply, string Tweeterusername, string ReplyuserName, string tweet);
    }
}
