﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TweetApp.Migrations
{
    public partial class AddReplyUserName : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ReplyUserName",
                table: "Replies",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ReplyUserName",
                table: "Replies");
        }
    }
}
