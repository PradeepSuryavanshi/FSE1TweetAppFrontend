﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TweetApp.Migrations
{
    public partial class IntialGrafPromDb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
