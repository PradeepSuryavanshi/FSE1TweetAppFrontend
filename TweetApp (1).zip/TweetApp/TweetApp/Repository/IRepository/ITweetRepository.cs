﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetApp.Model;
using TweetApp.Model.DTO;
using TweetApp.ViewModel;

namespace TweetApp.Repository.IRepository
{
    public interface ITweetRepository 
    {

        public Task<int> Register(User user);
        public Task<bool> CheckEmailExists(string Email);
        public Task<bool> CheckUserNameExists(string UserName);
        public Task<UserDTO> Login(string password, string username);
        public Task<Tweet> PostTweet(Tweet tweet);
        public Task<List<Tweet>> GetAllTweets();
        public Task<List<TweetViewModel>> GetAllTweetOfUser(string UserName);
        public Task<List<UsersViewModel>> GetAllUsers();
        public Task<UsersViewModel> GetUserByUserName(string UserName);
        public Task<bool> ForgotPassword(string Email, string oldPass, string newPass);
        public Task<bool> UpdateTweet(int TweetId, string NewTweetContent);
        public Task<bool> DeleteTweet(int TweetID);
        public Task<int> Likes(string username, string tweet, int tweetId);
        public Task<int> ReplyToTweet(string Reply, string Tweeterusername, string ReplyuserName, string tweet, DateTime date);
    }
}
