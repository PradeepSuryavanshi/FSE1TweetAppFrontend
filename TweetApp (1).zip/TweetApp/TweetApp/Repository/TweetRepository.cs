﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetApp.Model;
using TweetApp.Model.DTO;
using TweetApp.Repository.IRepository;
using TweetApp.ViewModel;

namespace TweetApp.Repository
{
    public class TweetRepository : ITweetRepository
    {
        private readonly TweetDbContext _context;
        public TweetRepository(TweetDbContext context)
        {
            this._context = context;
        }


        //Register User
        public async Task<int> Register(User user)
        {
            _context.Add(user);
            var result = await _context.SaveChangesAsync();
            return result;
        }

        public async Task<bool> CheckEmailExists(string Email)
        {
            var result = await _context.Users.FirstOrDefaultAsync(e => e.Email.ToLower() == Email.ToLower());
            if (result == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public async Task<bool> CheckUserNameExists(string UserName)
        {
            var result = await _context.Users.FirstOrDefaultAsync(e => e.UserName.ToLower() == UserName.ToLower());
            if (result == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        //public async Task<UserDTO> Login(string Password, string UserName)
        //{
        //    var user = await _context.Users.FirstOrDefaultAsync(e => e.UserName.ToLower() == UserName.ToLower());
        //    if (user != null)
        //    {
        //        if (user.Password == Password && (user.UserName.ToLower() == UserName.ToLower()))
        //        {

        //            return user;
        //        }
        //        else
        //        {
        //            return false;
        //        }
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //}
        public async Task<UserDTO> Login(string Password, string UserName)
        {
            var user = await _context.Users.FirstOrDefaultAsync(e => e.UserName.ToLower() == UserName.ToLower());
            if (user != null)
            {
                if (user.Password == Password && (user.UserName.ToLower() == UserName.ToLower()))
                {

                    return new UserDTO()
                    {
                        UserName = user.UserName,
                    };
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }

        public async Task<Tweet> PostTweet(Tweet tweet)
        {
            if (tweet != null)
            {
                int id = _context.Users.FirstOrDefault(e => e.UserName == tweet.UserName).UserId;
                tweet.UserId = id;
                tweet.TweetDate = DateTime.Now;
                _context.Tweets.Add(tweet);
                await _context.SaveChangesAsync();
                return tweet;
            }
            return null;
        }

        public async Task<List<Tweet>> GetAllTweets()
        {
            List<Tweet> tweetlist = await _context.Tweets.ToListAsync();
            return tweetlist;
        }

        // Tweet Of User
        public async Task<List<TweetViewModel>> GetAllTweetOfUser(string UserName)
        {
            var user1 = _context.Users.Where(e => e.UserName.ToLower() == UserName.ToLower()).FirstOrDefaultAsync().Result;
            if (user1 != null)
            {
                var result = await (from tweet in _context.Tweets
                                    join user in _context.Users
                                    on tweet.UserId equals user.UserId
                                    where tweet.UserId == user1.UserId
                                    select new TweetViewModel { 
                                        Tweet = tweet.TweetMessage, 
                                        UserName = user.UserName, 
                                        TweetDate = tweet.TweetDate, 
                                        Likes = tweet.Likes, 
                                        TweetId = tweet.TweetId,
                                        Replies = tweet.Replies
                                    }
                    ).ToListAsync();

                return result;
            }
            return null;
        }
        public async Task<List<UsersViewModel>> GetAllUsers()
        {
            List<UsersViewModel> UserList = await _context.Users.Select(e => new UsersViewModel
            {
                UserName = e.UserName,
                FirstName = e.FirstName,
                Lastname = e.LastName,
            }).ToListAsync();

            return UserList;
        }
        public async Task<UsersViewModel> GetUserByUserName(string UserName)
        {
            var RegisteredUser = await _context.Users.Where(e => e.UserName.ToLower() == UserName.ToLower()).FirstOrDefaultAsync();

            UsersViewModel user = new UsersViewModel();

            if (RegisteredUser != null)
            {
                user.UserName = RegisteredUser.UserName;
                user.FirstName = RegisteredUser.FirstName;
                user.Lastname = RegisteredUser.LastName;
                return user;
            }
            else
                return null;
        }

        public async Task<bool> ForgotPassword(string Email, string oldPass, string newPass)
        {
            var UpdatePass = await _context.Users.Where(e => e.Email.ToLower() == Email.ToLower() && e.Password == oldPass).FirstOrDefaultAsync();
            if (UpdatePass != null)
            {
                UpdatePass.Password = newPass;
                _context.Users.Update(UpdatePass);
                var success = await _context.SaveChangesAsync();
                if (success > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
                return false;
        }

        public async Task<bool> UpdateTweet(int TweetId, string NewTweetContent)
        {

            var updateTweet = _context.Tweets.FirstOrDefaultAsync(e => e.TweetId == TweetId).Result;
            updateTweet.TweetMessage = NewTweetContent;
            _context.Tweets.Update(updateTweet);
            await _context.SaveChangesAsync();
            return true;

        }

        public async Task<bool> DeleteTweet(int TweetID)
        {
            var DeleteFromReplies = _context.Replies.Where(e => e.TweetId == TweetID).ToList();
            foreach (var i in DeleteFromReplies)
            {
                _context.Replies.Remove(i);
                _context.SaveChanges();
            }

            var DeleteTweet = _context.Tweets.FirstOrDefault(e => e.TweetId == TweetID);
            _context.Tweets.Remove(DeleteTweet);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<int> Likes(string username, string tweet, int tweetId)
        {
            int id = _context.Users.FirstOrDefault(e => e.UserName == username).UserId;
            var result = _context.Tweets.FirstOrDefault(e => e.UserId == id && e.TweetMessage == tweet && e.TweetId == tweetId);

            result.Likes++;
            _context.Tweets.Update(result);
            await _context.SaveChangesAsync();
            return result.Likes;
        }

        public async Task<int> ReplyToTweet(string Reply, string Tweeterusername, string ReplyuserName, string tweet, DateTime date)
        {
            Reply comments = new Reply();
            //int results = 0;

            //id of user Who did Main tweet;
            int Tid = _context.Users.FirstOrDefault(e => e.UserName == Tweeterusername).UserId;

            //id of user Who is going to reply
            int Rid = _context.Users.FirstOrDefault(e => e.UserName == ReplyuserName).UserId;

            var result = await _context.Tweets.Where(s => s.UserId == Tid && s.TweetMessage == tweet).FirstOrDefaultAsync();
            if (result != null)

                comments.TweetId = result.TweetId;
            comments.UserId = Rid;
            comments.ReplyUserName = ReplyuserName;
            comments.ReplyToTweet = Reply;
            comments.ReplyDate = date;
            this._context.Replies.Add(comments);
            var results = await this._context.SaveChangesAsync();

            return results;
        }
    }
}