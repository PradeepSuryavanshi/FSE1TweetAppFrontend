﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using TweetApp.Model;

namespace TweetApp.ViewModel
{
    [NotMapped]
    public class TweetViewModel
    {
        public int TweetId { get; set; }
        public string Tweet { get; set; }
        public DateTime TweetDate { get; set; }
        public string UserName { get; set; }
        public int Likes { get; set; }
        public IList<Reply> Replies { get; set; }
    }
}
