﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetApp.Model;
using TweetApp.Service.ServiceInterface;
using TweetApp.ViewModel;

namespace TweetApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    // [Authorize]
    public class TweetController : ControllerBase
    {
        private readonly ITweetAppService _serivice;
        //private readonly IRabbitMQProducer _rabbitMQProducer;
        private readonly ILogger<TweetController> _logger;

        public TweetController(ITweetAppService service, ILogger<TweetController> logger)//,IRabbitMQProducer rabbitMQProducer)
        {
            this._serivice = service;
            this._logger = logger;
            //this._rabbitMQProducer = rabbitMQProducer;
        }

        [HttpPost]
        [Route("register")]
        [AllowAnonymous]
        public async Task<IActionResult> Register([FromBody] User user)
        {
            try
            {
                var result = await _serivice.Register(user);
                //_rabbitMQProducer.Publish("Registered Successfully....");
                _logger.LogInformation(user.Email + " Registered Successfully!!");
                return Ok(new JsonResult(result));
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Error occured while registering user");
                throw;
            }
        }

        [HttpPost]
        [Route("Login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login([FromBody] LoginViewModel login)
        {
            try
            {
                var token = await _serivice.Login(login.Password, login.UserName);
                if (token != null)
                {
                    //_rabbitMQProducer.Publish("User logged in....");
                    _logger.LogInformation(login.UserName + " LoggedIn!");
                    return Ok(new JsonResult(token));
                }
                else
                {
                    _logger.LogWarning("Unauthorized Request X");
                    return Unauthorized("Inavalid Credentials");
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error occured while login");
                throw;
            }
        }

        [HttpGet]
        [Route("PostTweet")]
        public async Task<IActionResult> PostTweet(string newTweet, string UserName)
        {
            try
            {
                Tweet tweet = new Tweet();
                tweet.TweetMessage = newTweet;
                tweet.UserName = UserName;
                var result = await _serivice.PostTweet(tweet);
                _logger.LogInformation(tweet.UserName + " Tweet Posted.");
                //_rabbitMQProducer.Publish("User Posted Tweet....");
                return Ok(result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Error occured while Tweet Posting");
                throw;
            }
        }

        [HttpGet]
        [Route("Like")]
        public async Task<IActionResult> Like(string UserName, string Tweet, int tweetId)
        {
            var Likes = await _serivice.Likes(UserName, Tweet, tweetId);
            //_rabbitMQProducer.Publish("User Liked Tweet....");
            _logger.LogInformation(UserName + "'s Tweet Liked!");
            return Ok(Likes);

        }

        [HttpGet]
        [Route("all")]
        public async Task<IActionResult> GetAllTweets()
        {
            try
            {
                var AllTweets = await _serivice.GetAllTweets();
                _logger.LogInformation("Tweet list displayed");
                //_rabbitMQProducer.Publish("User Requested for All Tweets....");
                return Ok(AllTweets);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Error occured while getting all Tweets");
                throw;
            }
        }

        [HttpGet]
        [Route("username")]
        public async Task<IActionResult> GetAllTweetOfUser(string UserName)
        {
            try
            {
                var result = await _serivice.GetAllTweetOfUser(UserName);
                if (result != null)
                {
                    _logger.LogInformation(UserName + "View All Tweets.");
                    return Ok(result);
                }
                else
                {
                    _logger.LogInformation("No Content Found!");
                    return NoContent();
                }
                    
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Error occured while getting tweets of user");
                throw;
            }
        }
        [HttpGet]
        [Route("update")]
        public async Task<IActionResult> UpdateTweet(int Tweetid, string NewTweetcontent)
        {
            try
            {
                var result = await _serivice.UpdateTweet(Tweetid, NewTweetcontent);
                //_rabbitMQProducer.Publish("User Updated tweet....");
                _logger.LogInformation(Tweetid + "Updated Tweet.");
                return Ok(result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Error occured while Tweet Update");
                throw;
            }
        }

        [HttpGet]
        [Route("Delete")]
        public async Task<IActionResult> DeleteTweet(int TweetId)
        {
            try
            {
                var result = await _serivice.DeleteTweet(TweetId);
                //_rabbitMQProducer.Publish("User deleted tweet....");
                _logger.LogInformation(TweetId + " Deleted");
                return Ok(result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Error occured while deleting tweet");
                throw;
            }
        }

        [HttpGet]
        [Route("Reply")]
        public async Task<IActionResult> ReplyToTweet(string Reply, string Tweeterusername, string ReplyuserName, string tweet)
        {
            try
            {
                var res = await _serivice.ReplyToTweet(Reply, Tweeterusername, ReplyuserName, tweet);
                //_rabbitMQProducer.Publish("user Replied to tweet....");
                _logger.LogInformation(Tweeterusername + "Reply Added");
                return Ok();
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Error occured while reply To tweet");
                throw;
            }
        }
        [HttpGet]
        [Route("users/all")]
        public async Task<IActionResult> GetAllUsers()
        {
            try
            {
                var users = await _serivice.GetAllUsers();
                //_rabbitMQProducer.Publish("User requested for users List....");
                _logger.LogInformation("Displayed Tweet Users");
                return Ok(users);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Error occured to get all Users");
                throw;
            }
        }

        //get User By UserName
        [HttpGet]
        [Route("user/search")]
        public async Task<IActionResult> SearchUserByUserName(string UserName)
        {
            try
            {
                var user = await _serivice.GetUserByUserName(UserName);
                if (user != null)
                {
                    //_rabbitMQProducer.Publish("User searched....");
                    _logger.LogInformation("Serached by user name.");
                    return Ok(new JsonResult(user));
                }
                else
                {
                    _logger.LogInformation("No User Found!");
                    return NotFound("No user with provided UserName");
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Error occured to get user by username");
                throw;
            }
        }

        [HttpGet]
        [Route("PasswordReset")]
        public async Task<IActionResult> ChangePassword(string Email, string OldPass, string NewPass)
        {
            try
            {
                var result = await _serivice.ResetPassword(Email, OldPass, NewPass);
                //_rabbitMQProducer.Publish("Password changed Successfully....");
                _logger.LogInformation("Password Changed!!");
                return Ok(result);

            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Error occured while chnage Password");
                throw;
            }
        }
    }
}
