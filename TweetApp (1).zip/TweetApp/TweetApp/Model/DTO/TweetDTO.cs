﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TweetApp.Model.DTO
{
    public class TweetDTO
    {
        public string UserName { get; set; }
        public string TweetMessage { get; set; }
        public DateTime TweetDate { get; set; }
        public IList<Reply> Replies { get; set; }
    }
}
