﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TweetApp.Model.DTO
{
    public class LoginDTO
    {
        public User user { get; set; }
    }
}
