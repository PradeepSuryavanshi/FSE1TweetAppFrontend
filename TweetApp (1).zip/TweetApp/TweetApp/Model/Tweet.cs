﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace TweetApp.Model
{
    public class Tweet
    {
        [Key]
        public int TweetId { get; set; }
        public string TweetMessage { get; set; }
        public DateTime TweetDate { get; set; }
        public IList<Reply> Replies { get; set; }
        public int Likes { get; set; }
        public string UserName { get; set; }      
        public int UserId { get; set; }
        [ForeignKey("UserId")]
        public virtual User Users { get; set; }
    }
}
