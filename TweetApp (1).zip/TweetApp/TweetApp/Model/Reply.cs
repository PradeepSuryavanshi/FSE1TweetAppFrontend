﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace TweetApp.Model
{
    public class Reply
    {
        public int ReplyId { get; set; }
        public DateTime ReplyDate { get; set; }
        [MaxLength(144)]
        public string ReplyToTweet { get; set; }
        public int? UserId { get; set; }

        public string ReplyUserName { get; set; }
       
        public int? TweetId { get; set; }
        [ForeignKey("TweetId")]
        public virtual Tweet Tweets { get; set; }
    }
}
